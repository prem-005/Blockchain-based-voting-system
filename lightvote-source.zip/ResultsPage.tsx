import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { 
  BarChart3, 
  Trophy, 
  CheckCircle2, 
  Lock, 
  Calendar, 
  Layers, 
  ArrowRight,
  ShieldCheck,
  Building
} from 'lucide-react';
import { apiRequest } from '../api/client';
import { useWeb3 } from '../context/Web3Context';
import { Election, Candidate } from '../types';

export const ResultsPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const [elections, setElections] = useState<Election[]>([]);
  const [selectedElectionId, setSelectedElectionId] = useState<string>(searchParams.get('election_id') || '');
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [candidateTallies, setCandidateTallies] = useState<Record<number, number>>({});
  const [totalVotes, setTotalVotes] = useState<number>(0);
  const [onChainVotes, setOnChainVotes] = useState<number>(0);
  const [ledgerReceiptCount, setLedgerReceiptCount] = useState<number>(0);
  const [onChainPublished, setOnChainPublished] = useState(false);
  const [loading, setLoading] = useState(true);
  const { getContract } = useWeb3();

  useEffect(() => {
    let active = true;
    const refreshElections = async () => {
      try {
        const data = await apiRequest('/elections/elections/');
        if (!active) return;
        const list: Election[] = data.results || data || [];
        setElections(list);
        if (list.length > 0) {
          setSelectedElectionId((current) =>
            searchParams.get('election_id') && list.some((election) => election.id.toString() === searchParams.get('election_id'))
              ? searchParams.get('election_id')!
              : list.some((election) => election.id.toString() === current) ? current : list[0].id.toString()
          );
        }
      } catch (err) {
        console.error('Could not refresh elections:', err);
      }
    };

    void refreshElections();
    const interval = window.setInterval(refreshElections, 15000);
    return () => {
      active = false;
      window.clearInterval(interval);
    };
  }, [searchParams]);

  useEffect(() => {
    if (!selectedElectionId) return;

    let active = true;
    let candidatesForElection: Candidate[] = [];
    let refreshing = false;
    setLoading(true);
    setCandidates([]);
    setCandidateTallies({});
    setTotalVotes(0);
    setOnChainVotes(0);
    setLedgerReceiptCount(0);
    setOnChainPublished(false);

    const refreshTallies = async () => {
      if (refreshing) return;
      refreshing = true;
      try {
        const lightVote = getContract('LightVote', false);
        const electionResults = getContract('ElectionResults', false);
        const electionId = BigInt(selectedElectionId);
        const [total, officialResult, ledgerData] = await Promise.all([
          lightVote ? lightVote.totalElectionVotes(electionId) : Promise.resolve(0n),
          electionResults?.getOfficialResult(electionId).catch(() => null) ?? null,
          apiRequest(`/explorer/transactions/?election_id=${selectedElectionId}`).catch(() => null),
        ]);
        if (!active) return;
        const chainTotal = Number(total);
        const verifiedReceiptCount = Array.isArray(ledgerData?.transactions)
          ? ledgerData.transactions.filter((receipt: any) => receipt.chain_status === 'CONFIRMED').length
          : 0;
        setOnChainVotes(chainTotal);
        setLedgerReceiptCount(verifiedReceiptCount);
        setTotalVotes(chainTotal);
        setOnChainPublished(Boolean(officialResult));

        // Public transaction calldata contains candidate IDs. The UI gates aggregate
        // tallies until publication, but that does not provide ballot secrecy.
        if (officialResult && candidatesForElection.length > 0 && electionResults) {
          const entries = await Promise.all(candidatesForElection.map(async (candidate) => {
            const candidateId = candidate.candidate_id || candidate.id;
            const votes = await electionResults.getOfficialCandidateVotes(electionId, BigInt(candidateId));
            return [candidateId, Number(votes)] as const;
          }));
          if (active) setCandidateTallies(Object.fromEntries(entries));
        } else if (active) {
          setCandidateTallies({});
        }
      } catch (contractErr) {
        console.warn('Could not refresh on-chain results:', contractErr);
      } finally {
        refreshing = false;
        if (active) setLoading(false);
      }
    };

    apiRequest(`/candidates/candidates/?election_id=${selectedElectionId}`)
      .then((candData) => {
        if (!active) return;
        candidatesForElection = candData.results || candData || [];
        setCandidates(candidatesForElection);
        void refreshTallies();
      })
      .catch((err) => {
        console.error('Could not load election candidates:', err);
        if (active) setLoading(false);
      });

    const interval = window.setInterval(() => void refreshTallies(), 5000);
    return () => {
      active = false;
      window.clearInterval(interval);
    };
  }, [selectedElectionId]);

  const currentElection = elections.find(e => e.id.toString() === selectedElectionId) || elections[0];
  const isPublished = onChainPublished;

  // Calculate winner
  const sortedCandidates = [...candidates].sort((a, b) => {
    const aVotes = candidateTallies[a.candidate_id || a.id] || 0;
    const bVotes = candidateTallies[b.candidate_id || b.id] || 0;
    return bVotes - aVotes;
  });

  const leadingCandidate = sortedCandidates[0];

  return (
    <div className="max-w-5xl mx-auto py-10 px-4 space-y-8">
      {/* Header & Election Selector */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-brand-50 text-brand-700 text-xs font-semibold rounded-full border border-brand-200 mb-2">
            <BarChart3 className="w-4 h-4 text-brand-600" />
            <span>Official Certified Tallies</span>
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            Election Results & Statistics
          </h1>
          <p className="text-slate-500 text-xs">
            Ballot totals refresh automatically. Candidate tallies appear after results are certified on-chain.
          </p>
        </div>

        {/* Election Selector */}
        <div className="flex items-center gap-2 bg-white px-3.5 py-2 rounded-xl border border-slate-200 shadow-sm text-xs">
          <span className="text-slate-500 font-medium">Select Cycle:</span>
          <select
            value={selectedElectionId}
            onChange={(e) => setSelectedElectionId(e.target.value)}
            className="font-bold text-slate-800 bg-transparent focus:outline-none cursor-pointer"
          >
            {elections.map((elec) => (
              <option key={elec.id} value={elec.id}>
                {elec.year} — {elec.name.slice(0, 35)}...
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-slate-400 text-xs font-semibold uppercase">Recorded Ballot Count</span>
          <p className="text-3xl font-extrabold text-slate-900 mono">
            {totalVotes.toLocaleString()}
          </p>
          <span className={`text-[11px] font-medium ${ledgerReceiptCount !== onChainVotes ? 'text-amber-700' : 'text-emerald-600'}`}>
            {ledgerReceiptCount === onChainVotes
              ? 'On-chain tally matches the receipt ledger'
              : `${ledgerReceiptCount.toLocaleString()} saved receipts; ${onChainVotes.toLocaleString()} votes on current chain`}
          </span>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-slate-400 text-xs font-semibold uppercase">Publication Status</span>
          <p className="text-base font-bold text-slate-900 flex items-center gap-1.5 pt-1">
            {isPublished ? (
              <span className="text-purple-700 flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4 text-purple-600" /> Certified & Published
              </span>
            ) : currentElection?.status === 'ACTIVE' ? (
              <span className="text-emerald-700 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                Active Voting Window
              </span>
            ) : (
              <span className="text-slate-600">Election Ended (Pending Publication)</span>
            )}
          </p>
          <span className="text-[11px] text-slate-400">
            {isPublished ? 'Immutable record on ElectionResults.sol' : 'Tallies gated by Election Commission'}
          </span>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-slate-400 text-xs font-semibold uppercase">Electoral Jurisdiction</span>
          <p className="text-sm font-bold text-slate-900 pt-1">
            Tamil Nadu (38 Districts)
          </p>
          <span className="text-[11px] text-slate-500">
            Assembly Segments AC-1 to AC-234
          </span>
        </div>
      </div>

      {/* Leading Candidate / Projected Winner */}
      {isPublished && leadingCandidate && totalVotes > 0 && (
        <div className="bg-gradient-to-r from-purple-900 to-brand-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex items-center justify-between gap-6 border border-purple-800">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-yellow-400/20 text-yellow-300 rounded-full text-xs font-bold border border-yellow-400/30">
              <Trophy className="w-4 h-4 text-yellow-400" />
              <span>Official Certified Winner / Frontrunner</span>
            </div>
            <h2 className="text-2xl font-black">{leadingCandidate.name}</h2>
            <p className="text-xs text-purple-200">
              {leadingCandidate.party_details?.name} ({leadingCandidate.party_details?.abbreviation}) • AC-{leadingCandidate.constituency}: {leadingCandidate.constituency_name}
            </p>
          </div>
          <div className="text-right">
            <span className="text-xs text-purple-200 uppercase font-semibold">Total Votes Received</span>
            <p className="text-3xl font-extrabold font-mono text-yellow-300">
              {(candidateTallies[leadingCandidate.candidate_id || leadingCandidate.id] || 0).toLocaleString()}
            </p>
            <span className="text-xs text-purple-200">
              {totalVotes > 0 ? `${(((candidateTallies[leadingCandidate.candidate_id || leadingCandidate.id] || 0) / totalVotes) * 100).toFixed(1)}% of total votes` : ''}
            </span>
          </div>
        </div>
      )}

      {/* Candidate Votes Breakdown */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900">
            Candidate Vote Tabulation Breakdown
          </h2>
          <span className="text-xs text-slate-500 font-medium">
            Cycle Year: <b>{currentElection?.year}</b>
          </span>
        </div>

        {loading ? (
          <div className="py-16 text-center text-slate-400 text-xs">
            Querying smart contract tallies...
          </div>
        ) : candidates.length === 0 ? (
          <div className="py-12 text-center text-slate-400 text-xs">
            {totalVotes > 0
              ? `${totalVotes.toLocaleString()} on-chain votes are recorded, but no candidate records are linked to this election in the registry.`
              : 'No candidates enrolled in this election cycle.'}
          </div>
        ) : (
          <div className="space-y-4">
            {!isPublished && (
              <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-xs text-amber-900">
                <p className="font-semibold">Candidate results are not certified yet.</p>
                <p className="mt-1 text-amber-800">
                  Candidate tallies are available after results are published on-chain. Candidate IDs remain visible in vote transaction calldata even while this page hides tallies.
                </p>
              </div>
            )}
            {sortedCandidates.map((cand) => {
              const cid = cand.candidate_id || cand.id;
              const votes = isPublished ? candidateTallies[cid] || 0 : null;
              const pct = totalVotes > 0 && votes !== null ? (votes / totalVotes) * 100 : 0;

              return (
                <div key={cand.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-xs shadow-sm"
                        style={{ backgroundColor: cand.party_details?.color_hex || '#2563EB' }}
                      >
                        {cand.party_details?.abbreviation || 'IND'}
                      </div>
                      <div>
                        <h3 className="font-bold text-slate-900 text-sm">{cand.name}</h3>
                        <p className="text-slate-500 text-[11px]">
                          {cand.party_details?.name} • AC-{cand.constituency}: {cand.constituency_name}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="font-mono font-bold text-slate-900 text-sm">
                        {isPublished ? `${votes?.toLocaleString()} votes` : 'Sealed'}
                      </span>
                      <span className="block text-[11px] text-slate-400 font-semibold">
                        {isPublished ? `${pct.toFixed(1)}%` : 'Awaiting certification'}
                      </span>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${Math.max(2, pct)}%`,
                        backgroundColor: cand.party_details?.color_hex || '#2563EB'
                      }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Multi-Year History Link */}
      <div className="text-center pt-4">
        <Link
          to="/history"
          className="text-xs text-brand-600 hover:underline font-bold inline-flex items-center gap-1.5"
        >
          <span>View Multi-Year Election History (2026 vs 2027 Isolation)</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
};
